from fastapi import FastAPI
from app.routers import users, ai_insight

app = FastAPI(title="RNRL TradeHub NonProd API")

@app.get('/health')
def health_check():
    return {"status": "healthy"}

app.include_router(users.router)
app.include_router(ai_insight.router)