from fastapi import APIRouter
from app.core.security import hash_password

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/register")
def register_user(email: str, password: str):
    hashed = hash_password(password)
    return {"email": email, "hashed_password": hashed}

@router.post("/login")
def login_user(email: str, password: str):
    return {"token": "fake-jwt-token-for-" + email}