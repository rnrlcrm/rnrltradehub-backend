from fastapi import APIRouter

router = APIRouter(prefix="/ai", tags=["AI Insights"])

@router.post("/predict")
def ai_predict(text: str):
    return {"input": text, "ai_response": "Predicted insight from Vertex AI"}