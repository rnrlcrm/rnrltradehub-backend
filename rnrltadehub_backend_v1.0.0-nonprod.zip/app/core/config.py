import os

class Settings:
    PROJECT_ID = "google-mpf-cas7ishusxmu"
    REGION = "us-central1"
    DB_HOST = os.getenv("DB_HOST", "127.0.0.1")
    DB_USER = os.getenv("DB_USER", "postgres")
    DB_PASSWORD = os.getenv("DB_PASSWORD", "")
    DB_NAME = os.getenv("DB_NAME", "rnrltadehub_nonprod")
    SECRET_KEY = os.getenv("SECRET_KEY", "supersecretkey")
    VERSION = "v1.0.0-nonprod"

settings = Settings()