# RNRL TradeHub Backend - NonProd v1.0.0

Secure FastAPI backend for Non-Production environment.
Includes Cloud Build CI/CD, PostgreSQL, and Vertex AI connectivity.

## Deployment
```
gcloud builds submit --config cloudbuild.yaml
```